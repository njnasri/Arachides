# Registre Arachides — version installable (PWA)

Ce dossier contient une vraie application web progressive (PWA) : une fois
hébergée en ligne, ton téléphone proposera de l'**installer** comme une appli
normale (icône sur l'écran d'accueil, plein écran, fonctionne hors ligne).

Fichiers : `index.html`, `manifest.json`, `service-worker.js`,
`icon-192.png`, `icon-512.png`, `icon-512-maskable.png`.
**Ne renomme aucun fichier** et garde-les tous dans le même dossier.

## 1. Héberger le dossier (choisis une option, gratuites)

**Netlify (le plus simple)**
1. Va sur netlify.com → crée un compte gratuit
2. "Add new site" → "Deploy manually"
3. Glisse-dépose ce dossier entier
4. Netlify te donne une adresse (ex. `https://arachides-nasri.netlify.app`)

**Vercel**
1. vercel.com → crée un compte
2. "Add New Project" → importe ce dossier (ou un repo GitHub contenant ces fichiers)
3. Déploie tel quel (pas de build nécessaire)

**GitHub Pages**
1. Crée un repo GitHub, mets-y ces fichiers
2. Settings → Pages → active "Deploy from branch" sur `main`
3. Ton site sera à `https://<utilisateur>.github.io/<repo>/`

## 2. Installer sur le téléphone

**Android (Chrome)**
1. Ouvre le lien du site sur ton téléphone
2. Un bandeau "Ajouter à l'écran d'accueil" apparaît (ou menu ⋮ → "Installer l'application")
3. Confirme — l'icône apparaît comme une vraie appli

**iPhone (Safari)**
1. Ouvre le lien dans Safari (obligatoire, pas Chrome)
2. Bouton Partager (carré avec flèche) → "Sur l'écran d'accueil"
3. Confirme — l'icône apparaît en plein écran, sans barre de navigateur

## Notes

- Tes données (parcelles, tarifs) sont stockées **directement sur ton
  téléphone** (localStorage du navigateur) — rien n'est envoyé à un serveur.
  Si tu changes de téléphone ou vides les données du navigateur, elles sont
  perdues : pas de sauvegarde automatique ailleurs.
- Le mode hors ligne fonctionne pour l'affichage de l'appli une fois qu'elle
  a été ouverte au moins une fois avec internet.
